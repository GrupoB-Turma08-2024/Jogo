# 🥦 As Aventuras De Brolli 🗺️
<hr>
Estamos animados em anunciar uma parceria com o Colégio Piaget! Juntos, estamos desenvolvendo um jogo emocionante que irá explorar o percurso de um alimento no corpo humano durante o processo de digestão, representando tanto as partes mecânicas quanto as químicas. 🍔🔬

Este jogo terá várias fases, cada uma delas contendo uma quantidade específica de perguntas. O objetivo é levar o conhecimento desse trajeto aos estudantes e tornar o estudo algo prático e dinâmico! 🎮✨

Prepare-se para uma aventura educacional épica! 🚀📚

Antes de Baixar o Jogo: 🔖
- Entrar no <bold>Disco Local C:</bold> do seu computador
- Criar uma pasta chamada "repositorio"
- Colocar o jogo lá dentro
- Entrar no Visual Studio Code (ter instalado o Java no computador)
- Entrar em Extensões
- Baixar o Java Extension Pack
- Reiniciar o Visual Studio Code
- Apertar Cntrl + K + O
- Selecionar o arquivo do jogo
- Entrar em src/main/java/telainicial/telaCover.java
- Agora basta rodar o código e aproveitar e se divertir com o jogo!
